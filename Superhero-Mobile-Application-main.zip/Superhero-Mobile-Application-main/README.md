# Superhero-Mobile-Application
A Superheroes app that displays a list of superheroes.

final app will have the following in both light and dark theme.
Android Studio Mobile App
